use std::io;

fn main() {
    println!("5 rounds of Rock Paper Scissors");
    println!("");

    println!("Up first is player 1");
    let player1 = get_player();
    println!("\n");
    println!("Next to enter inputs is player 2 and no cheating ;)");
    let player2 = get_player(); 

    winner(player1, player2);
}

fn get_player() -> [i32;5]
{
    let mut x = 1;
    let mut choice:[i32; 5] = [1;5];

    println!("1. Rock \n2. Paper \n3. Scissors \n");

    while x < 6
    {   
        println!("Choose either rock, paper, or scissors for round {0}", x);

        let mut take = String::new();
        io::stdin().read_line(&mut take)
            .expect("Sorry, I didn't understand that.");

        let take: i32 = match take.trim().parse() {
            Ok(num) => num,
            Err(_) => {
                println!("Please input a number to represent the choice");
                println!("");
                continue;
            }
        };

        choice[x-1] = take;
        x += 1;
    }
    println!("");
    return choice;
}

fn winner(play1:[i32;5], play2:[i32;5])
{
    let mut x = 1;
    let mut i = 0;
    let mut play_outcome1 = 0;
    let mut play_outcome2 = 0;

    while i < 5
    {
        println!("\nRound {} results", x);
        ////////////////Draws/////////////
        if play1[i] == 1 && play2[i] == 1
        {
            println!("Draw: Rock and Rock");
        }
        if play1[i] == 2 && play2[i] == 2
        {
            println!("Draw: Paper and Paper");
        }
        if play1[i] == 3 && play2[i] == 3
        {
            println!("Draw: Scissors and Scissors");
        }

        ////////////////Rock/////////////
        if play1[i] == 1 && play2[i] == 2
        {
            println!("Player 2 wins: Paper beats Rock");
            play_outcome2 += 1;
        }
        if play1[i] == 1 && play2[i] == 3
        {
            println!("Player 1 wins: Rock beats Scissors");
            play_outcome1 += 1;
        }

        ///////////////Paper/////////////
        if play1[i] == 2 && play2[i] == 1
        {
            println!("Player 1 wins: Paper beats Rock");
            play_outcome1 += 1;
        }
        if play1[i] == 2 && play2[i] == 3
        {
            println!("Player 2 wins: Scissors beats Paper");
            play_outcome2 += 1;
        }

        ////////////Scissors/////////////
        if play1[i] == 3 && play2[i] == 1
        {
            println!("Player 2 wins: Rock beats Scissors");
            play_outcome2 += 1;
        }
        if play1[i] == 3 && play2[i] == 2
        {
            println!("Player 1 wins: Scissors beats Paper");
            play_outcome1 += 1;
        }

        x += 1;
        i += 1;
    }

    println!("");

    if play_outcome1 > play_outcome2
    {println!("Player 1 wins with {0} win(s) to {1} win(s).", play_outcome1, play_outcome2);}
    if play_outcome1 < play_outcome2
    {println!("Player 2 wins with {0} win(s) to {1} win(s).", play_outcome2, play_outcome1);}
    else
    {println!("It is a draw as Player 1 has {0} win(s) and Player 2 has {1} win(s).", play_outcome1, play_outcome2);}
    

}