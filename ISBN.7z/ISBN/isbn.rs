use std::io;

fn main() {
    println!("Welcome to an ISBN marker calculater.");
    println!("");

    let isbn = get_isbn();  
    println!("The isbn without the marker is: ");
    for i in 0..isbn.len()
    {print!("{}", isbn[i]);}

    let isbn_marker = calculte_marker(isbn);

    println!("");
    println!("");

    println!("The isbn with the marker is: ");
    for i in 0..isbn.len()
    {print!("{}", isbn[i]);}

    if isbn_marker >= 10
        {print!("X");}
    else
        {print!("{}", isbn_marker);}
}

fn get_isbn() -> [i32;9]
{
    let mut x = 1;
    let mut numbers:[i32; 9] = [0;9];

    while x < 10
    {   
        println!("Enter a number between 1 and 9 for number {0}", x);

        let mut take = String::new();
        io::stdin().read_line(&mut take)
            .expect("Sorry, I didn't understand that.");

        let take: i32 = match take.trim().parse() {
            Ok(num) => num,
            Err(_) => {
                println!("Invalid input");
                println!("");
                continue;
            }
        };

        numbers[x-1] = take;
        x += 1;
    }
    println!("");
    return numbers;
}

fn calculte_marker(arr:[i32;9]) -> i32
{
    let mut multiplications:[i32; 9] = [0;9];
    for i in 0..arr.len()
    {
        let x = i+1;
        multiplications[i] = arr[i] * (x as i32); //have to cast the x as a signed i32
    }
  
    let mut number:i32 = 0; 
    for i in 0..multiplications.len()
    {
        number += multiplications[i];
    }

    let marker:i32 = number % 11;
    return marker;
}