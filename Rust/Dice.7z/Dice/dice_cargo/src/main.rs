use rand::Rng;

fn main() {
    println!("This program will roll two dice for you and output their numbers and then their sum");
    println!("");

    let dice1 = roll_dice(); 
    println!("Dice one is: {} \n", dice1);
    let dice2 = roll_dice(); 
    println!("Dice one is: {} \n", dice2);

    let sum = dice1 + dice2;
    println!("The sum of the two dice is: {}", sum);
}

fn roll_dice() -> i32
{
    let mut rng = rand::thread_rng();
    let roll = rng.gen_range(1,7);

    return roll;
}
