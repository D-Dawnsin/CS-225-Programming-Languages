use std::io;

fn main() {
    let mut sticks = 20;
    println!("Stick game");
    println!("Starting with {} sticks.", sticks);
    println!("");
 
    loop {
        sticks = p_turn(&sticks);
        print_remaining(&sticks);
        if sticks == 0 {
            println!("The player took the last stick. \nComputer wins!");
            break;
        }

        sticks = c_turn(&sticks);
        print_remaining(&sticks);
        if sticks == 0 {
            println!("The computer took the last stick. \nPlayer wins!");
            break;
        }
    }
}

fn p_turn(sticks: &i32) -> i32 { //(argument) -> return type
    loop {  //try until we get a good number
        println!("How many sticks would you like to take?");
 
        let mut take = String::new();
        io::stdin().read_line(&mut take)
            .expect("Sorry, I didn't understand that.");
 
        let take: i32 = match take.trim().parse() {
            Ok(num) => num,
            Err(_) => {
                println!("Invalid input");
                println!("");
                continue;
            }
        };
 
        if take > 3 || take < 1 {
            println!("Take must be between 1 and 3.");
            println!("");
            continue;
        }
 
        return sticks - take;
    }
}
 
fn c_turn(sticks: &i32) -> i32 {
    let mut take = sticks % 4;

    if sticks < &4
    {
        if sticks == &2
        {
            take = 1
        }
        else
        {
            take = sticks % 2;
        }
    }
 
    println!("Computer takes {} sticks.", take);
 
    return sticks - take;
}
 
fn print_remaining(sticks: &i32) {
    println!("{} sticks remaining.", sticks);
    println!("");
}